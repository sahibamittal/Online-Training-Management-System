<html>
<head>
<title>Searching...</title>

<link href="css/style2.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php

$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

        $username = $_POST['username'];
        $password = $_POST['password'];
        $newpassword = $_POST['newpassword'];
        $confirmnewpassword = $_POST['confirmnewpassword'];
        $result = mysqli_query($con,"SELECT * FROM studentlogin WHERE username='$username'");
       $rs = mysqli_fetch_array($result);
        if(!$rs)
        {
        echo "<br>The username you entered does not exist";
        }
        else if($password!= $rs['password'])
        {
        echo "<br>You entered an incorrect password";
        }
        else if($newpassword==$confirmnewpassword){
        $sql=mysqli_query($con,"UPDATE studentlogin SET password='$newpassword' where username='$username'");
      if($sql)
        {
        echo "<br>Congratulations You have successfully changed your password<br><br>
Please press back to login again ";
        }
     else{
  echo "<br>Passwords do not match"; }
       } 
      ?>

<br><br><br>

<center><div class="footer">
    <a href="login.htm" style="text-decoration:none;"><input type="button" name="back" value="Back" class="button"/></a><br></br> 
</div></center>

</body>
</html>