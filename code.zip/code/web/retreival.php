<html>
<head>
<title>Retreival</title>

<link href="css/style2.css" rel="stylesheet" type="text/css" />
<style>
table,th,td
{
border:1px solid black;
width:300px;
padding:10px;
border-spacing:5px;
}
</style>

</head>
<body>
<a href="login.htm" style="float:right;">>>Logout<<</a><br>

<?php
$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con,"SELECT ID,STUDENT_NAME FROM traineedetail ORDER BY STUDENT_NAME");

echo"<center>";
echo "<table>
<tr>
<th>ID</th>
<th>Student Name</th>
</tr>";

while($row = mysqli_fetch_array($result)) {
  echo "<tr>";
  echo "<td>" . $row['ID'] . "</td>";
  echo "<td>" . $row['STUDENT_NAME'] . "</td>";
  echo "</tr>";
}
echo "</table>";
echo"</center>";

?>

<br><br>
<center><div class="search">
	<div id="tfheader">
		<form id="tfnewsearch" method="get" action="searchresult.php">
		        <input type="number" class="tftextinput" name="searchid" size="21" maxlength="120" required><input type="submit" value="Search by ID " class="tfbutton">
		</form>
	<div class="tfclear"></div>
	</div>
</div>
<br><br>
<div class="footer">
	<a href="view-all.php" style="text-decoration:none;"><input type="button" name="new" value="View All" class="button"/></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
	<a href="afterlogin.php" style="text-decoration:none;"><input type="button" name="back" value="Back" class="button"/></a><br></br> 
</div></center>    

</body>
</html>