<html>
<head>
<title>New Student</title>

<link href="css/style2.css" rel="stylesheet" type="text/css" />

</head>
<body>
<br>
<p><center><h2> Thankyou for registration !! Your unique ID will be alloted on completion</h2></center></p>

<?php
$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$studentname = mysqli_real_escape_string($con, $_POST['studentname']);
$coursename = mysqli_real_escape_string($con, $_POST['coursename']);
$branch = mysqli_real_escape_string($con, $_POST['branch']);
$year = mysqli_real_escape_string($con, $_POST['year']);
$college = mysqli_real_escape_string($con, $_POST['college']);
$address = mysqli_real_escape_string($con, $_POST['address']);
$commencedate = mysqli_real_escape_string($con, $_POST['commencedate']);
$recommby = mysqli_real_escape_string($con, $_POST['recommby']);
$referby = mysqli_real_escape_string($con, $_POST['referby']);
$letterno = mysqli_real_escape_string($con, $_POST['letterno']);

$sql="INSERT INTO studententry (STUDENT_NAME, COURSE_NAME, BRANCH, CURRENT_YEAR, COLLEGE, ADDRESS, COMMENCE_DATE, RECOMM_BY, REFER_BY, LETTER_NO)
VALUES ('$studentname', '$coursename', '$branch', '$year', '$college', '$address', '$commencedate', '$recommby', '$referby', '$letterno')";

if (!mysqli_query($con,$sql)) {
  die('Error: ' . mysqli_error($con));
}
echo "<br><br> Record saved.. ";
echo "<br><br>";

?>

<center><div class="footer">
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
     <a href="http://localhost/afterloginstudent.php" style="text-decoration:none;"><input type="button" name="back" value="Back to HomePage" class="button"/></a><br>

</div></center>

</body>
</html>