<html>
<head>
<title>Welcome Admin</title>
</head>

<link href="css/style2.css" rel="stylesheet" type="text/css" />

<body>
<a href="login.htm" style="float:right;">>>Logout<<</a><br>
<?php

$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

    echo'
	<html>
    <h1 align=center> Welcome to <br>
     Training Management System </h1><br><br><br>
    <center><img src="drdo.jpg" alt="image description"></center>
    <br><br><br>
     <center><div class="footer">
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
    <a href="new-form.htm" style="text-decoration:none;"><input type="button" name="new" value="New" class="button"/></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
     <a href="retreival.php" style="text-decoration:none;"><input type="button" name="retreive" value="Retreive" class="button"/></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
     <a href="after-update.htm" style="text-decoration:none;"><input type="button" name="update" value="Update" class="button"/></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
     <a href="after-delete.htm" style="text-decoration:none;"><input type="button" name="delete" value="Delete" class="button"/></a><br><br>
    <a href="upload.php" style="text-decoration:none;"><input type="button" name="upload" value="Upload from student DB" class="button"/></a>
    </div></center><br><br>
    </html>
     ' ;

?> 
</body>
</html>
