<html>
<head>
<title>Login in process</title>

</head>
<body>
<?php
$username = $_POST['username'];
$password = $_POST['password'];

$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con,"SELECT username,password FROM login");
$row = mysqli_fetch_array($result);

$result2 = mysqli_query($con,"SELECT username,password FROM studentlogin");
$row2 = mysqli_fetch_array($result2);

if ($username==$row['username']&&$password==$row['password']) {
echo "<meta http-equiv=\"refresh\" content=\"0;URL=afterlogin.php\">";
}

else{
do{
if($row2['username']==$username&&$row2['password']==$password) {
echo"<meta http-equiv=\"refresh\" content=\"0;URL=afterloginstudent.php\">";
exit;
}}while($row2 = mysqli_fetch_array($result2));
echo "<script>alert('Wrong username or password')</script>";
    echo '<a href="login.htm">Login again</a>';
}
?> 
</body>
</html>
