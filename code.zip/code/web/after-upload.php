<html>
<head>
<title>New Student</title>

<link href="css/style2.css" rel="stylesheet" type="text/css" />

</head>
<body>

<p><center><h1> Uploaded !! </h1></center></p>

<?php

$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$checked=$_POST['check'];

echo "$checked";

if(empty($checked))
  {
    echo("You didn't select any.");
  }
  else
  {
$N = sizeof($checked);
echo "$N";
if($_POST["submit"]=="submit")
{
for($i=0; $i<$N; $i++) {
$sql = "INSERT INTO traineedetail (STUDENT_NAME, COURSE_NAME, BRANCH, CURRENT_YEAR, COLLEGE, ADDRESS, COMMENCE_DATE, RECOMM_BY, REFER_BY, LETTER_NO)
VALUES('".$checked[$i]['studentname']."', '".$checked[$i]['coursename']."', '".$checked[$i]['branch']."', '".$checked[$i]['year']."', '".$checked[$i]['college']."', '".$checked[$i]['address']."', '".$checked[$i]['commencedate']."', '".$checked[$i]['recommby']."', '".$checked[$i]['referby']."', '".$checked[$i]['letterno']."')";
}
if (!mysqli_query($con,$sql)) {
  die('Error: '.mysqli_error($con));
}}
}
echo "<br><br>";

?>

<center><div class="footer">
     <a href="http://localhost/afterlogin.php"><input type="button" name="back" value="Back to HomePage" class="button"/></a><br>
</div></center>

</body>
</html>