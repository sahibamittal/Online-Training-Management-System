<html>
<head>
<title>New Student</title>

<link href="css/style2.css" rel="stylesheet" type="text/css" />

</head>
<body>

<p><center><h1> New Student Added !! </h1></center></p>

<?php
$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$studentname = mysqli_real_escape_string($con, $_POST['studentname']);
$coursename = mysqli_real_escape_string($con, $_POST['coursename']);
$branch = mysqli_real_escape_string($con, $_POST['branch']);
$year = mysqli_real_escape_string($con, $_POST['year']);
$college = mysqli_real_escape_string($con, $_POST['college']);
$address = mysqli_real_escape_string($con, $_POST['address']);
$duration = mysqli_real_escape_string($con, $_POST['duration']);
$commencedate = mysqli_real_escape_string($con, $_POST['commencedate']);
$recommby = mysqli_real_escape_string($con, $_POST['recommby']);
$referby = mysqli_real_escape_string($con, $_POST['referby']);
$letterno = mysqli_real_escape_string($con, $_POST['letterno']);
$apprecdate = mysqli_real_escape_string($con, $_POST['apprecdate']);

$sql="INSERT INTO traineedetail (STUDENT_NAME, COURSE_NAME, BRANCH, CURRENT_YEAR, COLLEGE, ADDRESS, TRAINING_DURATION, COMMENCE_DATE, RECOMM_BY, REFER_BY, LETTER_NO, APP_REC_DATE)
VALUES ('$studentname', '$coursename', '$branch', '$year', '$college', '$address', '$duration', '$commencedate', '$recommby', '$referby', '$letterno', '$apprecdate')";

if (!mysqli_query($con,$sql)) {
  die('Error: ' . mysqli_error($con));
}
echo "1 more record added";
echo "<br><br>";

?>

<center><div class="footer">
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
    <a href="new-form.htm" style="text-decoration:none;"><input type="button" name="addmore" value="Add More" class="button"/></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
     <a href="http://localhost/afterlogin.php" style="text-decoration:none;"><input type="button" name="back" value="Back to HomePage" class="button"/></a><br>

</div></center>

</body>
</html>