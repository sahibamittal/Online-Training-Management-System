<html>
<head>
<title>Welcome Student</title>
</head>

<link href="css/style2.css" rel="stylesheet" type="text/css" />

<body>
<a href="login.htm" style="float:right;">>>Logout<<</a><br>

<?php

$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

    echo'
	<html>
    <h1 align=center> Welcome to <br>
     Training Management system </h1><br><br><br>
    <center><img src="drdo.jpg" alt="image description"></center>
    <br><br><br>
     <center><div class="footer">
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
    <a href="new-form-student.htm" style="text-decoration:none;"><input type="button" name="new" value="New Form" class="button"/></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
     <a href="retreival-student.htm" style="text-decoration:none;"><input type="button" name="retreive" value="Retreive if registered" class="button"/></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;
     </div></center><br><br>
    </html>
     ' ;

?> 
</body>
</html>
