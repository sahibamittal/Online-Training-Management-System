-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2014 at 08:12 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `studententry`
--

CREATE TABLE IF NOT EXISTS `studententry` (
  `S.NO.` int(3) NOT NULL AUTO_INCREMENT,
  `STUDENT_NAME` varchar(20) NOT NULL,
  `COURSE_NAME` varchar(8) NOT NULL,
  `BRANCH` varchar(25) NOT NULL,
  `CURRENT_YEAR` int(2) NOT NULL,
  `COLLEGE` varchar(60) NOT NULL,
  `ADDRESS` varchar(40) NOT NULL,
  `COMMENCE_DATE` date NOT NULL,
  `RECOMM_BY` varchar(20) NOT NULL,
  `REFER_BY` varchar(20) NOT NULL,
  `LETTER_NO` int(11) NOT NULL,
  PRIMARY KEY (`S.NO.`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `studentlogin`
--

CREATE TABLE IF NOT EXISTS `studentlogin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `studentlogin`
--

INSERT INTO `studentlogin` (`username`, `password`) VALUES
('arpit', 'arpitsri'),
('sahiba', 'mittals');

-- --------------------------------------------------------

--
-- Table structure for table `traineedetail`
--

CREATE TABLE IF NOT EXISTS `traineedetail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `STUDENT_NAME` varchar(20) NOT NULL,
  `COURSE_NAME` varchar(8) NOT NULL,
  `BRANCH` varchar(25) NOT NULL,
  `CURRENT_YEAR` int(2) NOT NULL,
  `COLLEGE` varchar(60) NOT NULL,
  `ADDRESS` varchar(40) NOT NULL,
  `TRAINING_DURATION` int(11) NOT NULL COMMENT 'weeks',
  `COMMENCE_DATE` date NOT NULL,
  `RECOMM_BY` varchar(20) NOT NULL,
  `REFER_BY` varchar(20) NOT NULL,
  `LETTER_NO` int(11) NOT NULL,
  `APP_REC_DATE` date NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`),
  FULLTEXT KEY `ADDRESS` (`ADDRESS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
