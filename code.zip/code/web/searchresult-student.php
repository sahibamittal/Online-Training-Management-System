<html>
<head>
<title>Searching...</title>

<link href="css/style2.css" rel="stylesheet" type="text/css" />
<style>
table,th,td
{
border:1px solid black;
width:300px;
padding:10px;
border-spacing:5px;
}
</style>

</head>
<body>
<a href="login.htm" style="float:right;">>>Logout<<</a><br>
<center><h1> Result found </h1></center><br><br>

<?php 
	$searchid = $_GET['searchid'];
	
$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con,"SELECT * FROM traineedetail WHERE ID=$searchid ORDER BY STUDENT_NAME ");

$rs = mysqli_fetch_array($result);
        if ( $rs == FALSE )
        {
             echo "<center><h3>No result found !! </h3></center>";
        }
        else
        {

echo"<center>";
echo "<table>
<tr>
<th>ID</th>
<th>Student Name</th>
<th>Course Name</th>
<th>Branch</th>
<th>Current Year</th>
<th>College</th>
<th>Address</th>
<th>Training Duration</th>
<th>Commence Date</th>
<th>Recomm. By</th>
<th>Referred By</th>
<th>Letter no. </th>
<th>App. Rec. Date</th>
</tr>";

$result = mysqli_query($con,"SELECT * FROM traineedetail WHERE ID=$searchid ORDER BY STUDENT_NAME ");

while($row=mysqli_fetch_array($result)) {
  echo "<tr>";
  echo "<td>" . $row['ID'] . "</td>";
  echo "<td>" . $row['STUDENT_NAME'] . "</td>";
  echo "<td>" . $row['COURSE_NAME'] . "</td>";
  echo "<td>" . $row['BRANCH'] . "</td>";
  echo "<td>" . $row['CURRENT_YEAR'] . "</td>";
  echo "<td>" . $row['COLLEGE'] . "</td>";
  echo "<td>" . $row['ADDRESS'] . "</td>";
  echo "<td>" . $row['TRAINING_DURATION'] . "</td>";
  echo "<td>" . $row['COMMENCE_DATE'] . "</td>"; 
  echo "<td>" . $row['RECOMM_BY'] . "</td>";
  echo "<td>" . $row['REFER_BY'] . "</td>";
  echo "<td>" . $row['LETTER_NO'] . "</td>";
  echo "<td>" . $row['APP_REC_DATE'] . "</td>";
 echo "</tr>";
}
echo "</table>";
echo"</center>";

}

?>
<br><br><br>

<center><div class="footer">
    <a href="retreival-student.htm" style="text-decoration:none;"><input type="button" name="back" value="Back" class="button"/></a><br></br> 
</div></center>


</body>
</html>