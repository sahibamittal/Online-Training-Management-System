<html>
<head>
<title>Updation</title>

<link href="css/style2.css" rel="stylesheet" type="text/css" />
<style>
table,th,td
{
border:1px solid black;
width:300px;
padding:10px;
border-spacing:5px;
}
</style>

</head>
<body>

<a href="login.htm" style="float:right;">>>Logout<<</a><br>

<?php

$con=mysqli_connect("","root","embedded","my_db");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$uid=mysqli_real_escape_string($con, $_POST['id']);
$ustudentname = mysqli_real_escape_string($con, $_POST['studentname']);
$ucoursename = mysqli_real_escape_string($con, $_POST['coursename']);
$ubranch = mysqli_real_escape_string($con, $_POST['branch']);
$uyear = mysqli_real_escape_string($con, $_POST['year']);
$ucollege = mysqli_real_escape_string($con, $_POST['college']);
$uaddress = mysqli_real_escape_string($con, $_POST['address']);
$uduration = mysqli_real_escape_string($con, $_POST['duration']);
$ucommencedate = mysqli_real_escape_string($con, $_POST['commencedate']);
$urecommby = mysqli_real_escape_string($con, $_POST['recommby']);
$ureferby = mysqli_real_escape_string($con, $_POST['referby']);
$uletterno = mysqli_real_escape_string($con, $_POST['letterno']);
$uapprecdate = mysqli_real_escape_string($con, $_POST['apprecdate']);

$sql="UPDATE traineedetail 
SET STUDENT_NAME='$ustudentname', COURSE_NAME='$ucoursename', BRANCH='$ubranch', CURRENT_YEAR='$uyear', COLLEGE='$ucollege', ADDRESS ='$uaddress', TRAINING_DURATION='$uduration', COMMENCE_DATE='$ucommencedate', RECOMM_BY='$urecommby', REFER_BY='$ureferby', LETTER_NO='$uletterno', APP_REC_DATE='$uapprecdate' 
WHERE ID='$uid'";

if (!mysqli_query($con,$sql)) {
  die('Error: ' . mysqli_error($con));
}

if($con->query($sql) == false) {
  trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $con->error, E_USER_ERROR);
} else {
  $affected_rows = $con->affected_rows;
}

$result = mysqli_query($con,"SELECT * FROM traineedetail WHERE ID='$uid' ");
$row=mysqli_fetch_array($result);

echo "<center><h3>Updated data successfully !! </h3></center><br><br>";

echo"<center>";
echo "<table>
<tr>
<th>ID</th>
<th>Student Name</th>
<th>Course Name</th>
<th>Branch</th>
<th>Current Year</th>
<th>College</th>
<th>Address</th>
<th>Training Duration</th>
<th>Commence Date</th>
<th>Recomm. By</th>
<th>Referred By</th>
<th>Letter no. </th>
<th>App. Rec. Date</th>
</tr>";

  echo "<tr>";
  echo "<td>" . $row['ID'] . "</td>";
  echo "<td>" . $row['STUDENT_NAME'] . "</td>";
  echo "<td>" . $row['COURSE_NAME'] . "</td>";
  echo "<td>" . $row['BRANCH'] . "</td>";
  echo "<td>" . $row['CURRENT_YEAR'] . "</td>";
  echo "<td>" . $row['COLLEGE'] . "</td>";
  echo "<td>" . $row['ADDRESS'] . "</td>";
  echo "<td>" . $row['TRAINING_DURATION'] . "</td>";
  echo "<td>" . $row['COMMENCE_DATE'] . "</td>"; 
  echo "<td>" . $row['RECOMM_BY'] . "</td>";
  echo "<td>" . $row['REFER_BY'] . "</td>";
  echo "<td>" . $row['LETTER_NO'] . "</td>";
  echo "<td>" . $row['APP_REC_DATE'] . "</td>";
 echo "</tr>";

echo "</table>";
echo"</center>";

?>

<br><br>
</div></center>
<br><br>	
<center><div class="footer">
	<a href="after-update.htm" style="text-decoration:none;"><input type="button" name="back" value="Update more / Back" class="button"/></a><br></br> 
</div></center>
 
</body>
</html>